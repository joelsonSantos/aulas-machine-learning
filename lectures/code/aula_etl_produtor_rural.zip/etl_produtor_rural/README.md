# Do arquivo ao contrato · Aula guiada em PySpark

Material prático da aula de ETL multi-fonte: produtores rurais (pessoa física e jurídica) consolidados no contrato `produtor_rural.v1` para modelagem de score de crédito.

## Conteúdo

| Arquivo | Para quê |
|---|---|
| `aula_etl_produtor_rural.ipynb` | notebook do aluno, com exercícios para completar (`TODO`) |
| `aula_etl_produtor_rural_GABARITO.ipynb` | mesmo notebook com as soluções e respostas sugeridas |
| `gerar_dados.py` | gera todas as bases sintéticas (só biblioteca padrão, semente fixa) |
| `gabarito_esperado.json` | resultados esperados, usados pelas células de verificação |
| `dados/` | as bases já geradas, prontas para uso |

```
dados/
├── landing/
│   ├── cooperativa/                 cooperados_20261027.csv          CSV, ";" e Latin-1
│   ├── revenda/                     clientes_20261027_loja01.txt     TXT de largura fixa
│   │                                clientes_20261027_loja02.txt     (trailer divergente de propósito)
│   ├── monitoramento/               imoveis_20261027.json            JSON aninhado, multilinha
│   ├── cadastro_pj/                 estabelecimentos_20261027.xml    XML, inclui CNPJ alfanumérico
│   ├── cadastro_pj_semana_anterior/ estabelecimentos_20261020.xml    exercício de inferência de schema
│   └── assistencia_tecnica/         visitas_20261027.jsonl           desafio final (áreas em alqueires)
├── referencia/                      municipios_ibge.csv, zarc_2026_27.csv
└── contratos/                       produtor_rural.v1.schema.json
```

## Como rodar

1. Requisitos: Python 3.9+, Java 17 ou 21, PySpark 4.x (ou 3.5, que baixa o pacote `spark-xml` automaticamente) e `jsonschema`.
   ```bash
   pip install "pyspark>=4.0" jsonschema jupyter
   ```
2. Abra o notebook na pasta deste README (os caminhos são relativos a ela).
3. Execute as células em ordem. As células "✅ Verificação" comparam seus resultados com `gabarito_esperado.json` e mostram ✔ ou ✘.

Para recriar as bases do zero: `python gerar_dados.py` (os arquivos saem idênticos, porque a semente é fixa).

## Problemas injetados de propósito

* **Cooperativa:** CPF/CNPJ com e sem máscara, CPF sem o zero inicial, nomes com espaços duplos e minúsculas, municípios com erro de digitação, CNAE ausente para PJ, CAR em minúsculas, com espaços ou truncado, área vazia ou `n/d`, áreas declaradas infladas.
* **Revenda:** documentos completados com zeros até 14 posições, CPFs com dígito verificador errado, produtor repetido nas duas lojas, trailer que não confere.
* **Monitoramento:** imóveis com dois proprietários, plantio não detectado, código IBGE numérico.
* **Cadastro PJ:** CNPJ alfanumérico, empresa sem CNAE principal, CNAE único (armadilha da inferência).

## Observações

* Nomes, CPFs, CNPJs e códigos CAR são **fictícios**. Os documentos têm dígitos verificadores válidos apenas para exercitar as regras de validação.
* Os códigos IBGE dos 16 municípios são reais (conferidos pelo dígito verificador do código), mas a tabela é só um extrato. A tabela ZARC é **fictícia** e simplificada; para uso real, consulte as tábuas oficiais do Ministério da Agricultura.
* O `gabarito_esperado.json` é calculado por uma reimplementação em Python puro das mesmas regras do notebook (função `gabarito` em `gerar_dados.py`). Se uma verificação der ✘, compare a etapa correspondente nas duas implementações.
