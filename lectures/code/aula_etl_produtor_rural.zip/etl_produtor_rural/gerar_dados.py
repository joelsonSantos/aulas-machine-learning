#!/usr/bin/env python3
"""
Gera as bases sintéticas da aula guiada "Do arquivo ao contrato: produtores rurais".

Uso:
    python gerar_dados.py            # cria ./dados e ./gabarito_esperado.json
    python gerar_dados.py minha_pasta

Usa apenas a biblioteca padrão do Python. A semente é fixa, então os arquivos
saem sempre iguais. Todos os nomes, CPFs, CNPJs e códigos CAR são fictícios;
os documentos têm dígitos verificadores válidos apenas para que as regras de
validação possam ser exercitadas. Os códigos IBGE dos municípios são reais.
A tabela de zoneamento (ZARC) é fictícia e simplificada.
"""
import csv
import json
import math
import os
import random
import re
import sys
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from xml.sax.saxutils import escape, quoteattr

SEED = 20261027
DATA_REF = date(2026, 10, 27)
TAG = "20261027"
R = random.Random(SEED)

# ---------------------------------------------------------------- referência
MUNICIPIOS = [  # código IBGE, nome, UF, peso no sorteio
    ("5107925", "Sorriso", "MT", 4), ("5107909", "Sinop", "MT", 3),
    ("5105259", "Lucas do Rio Verde", "MT", 3), ("5106224", "Nova Mutum", "MT", 2),
    ("5107040", "Primavera do Leste", "MT", 2), ("5218805", "Rio Verde", "GO", 3),
    ("5211909", "Jataí", "GO", 2), ("5206206", "Cristalina", "GO", 2),
    ("4104808", "Cascavel", "PR", 2), ("4127700", "Toledo", "PR", 2),
    ("4123501", "Santa Helena", "PR", 1), ("4215356", "Santa Helena", "SC", 1),
    ("2919553", "Luís Eduardo Magalhães", "BA", 3), ("2903201", "Barreiras", "BA", 2),
    ("5003702", "Dourados", "MS", 2), ("5005400", "Maracaju", "MS", 2),
]
UF_IBGE = {"11": "RO", "12": "AC", "13": "AM", "14": "RR", "15": "PA", "16": "AP", "17": "TO",
           "21": "MA", "22": "PI", "23": "CE", "24": "RN", "25": "PB", "26": "PE", "27": "AL",
           "28": "SE", "29": "BA", "31": "MG", "32": "ES", "33": "RJ", "35": "SP", "41": "PR",
           "42": "SC", "43": "RS", "50": "MS", "51": "MT", "52": "GO", "53": "DF"}
CULTURAS = {"SOJA": ("Soja", "001"), "MILHO": ("Milho", "002"), "ALGODAO": ("Algodão", "003")}
CNAES_PJ = ["0115600", "0115600", "0115600", "0111302", "0112101", "0113000", "0151201", "0141501"]

PRIMEIROS = ["João", "José", "Antônio", "Francisco", "Carlos", "Paulo", "Pedro", "Lucas", "Luiz",
             "Marcos", "Luís", "Gabriel", "Rafael", "Daniel", "Marcelo", "Bruno", "Eduardo",
             "Felipe", "Ademir", "Rodrigo", "Maria", "Ana", "Francisca", "Antônia", "Adriana",
             "Juliana", "Márcia", "Fernanda", "Patrícia", "Aline", "Sandra", "Camila", "Lurdes",
             "Conceição", "Lúcia", "Helena", "Rosângela", "Cláudia", "Débora", "Tânia", "Rosane",
             "Osvaldo", "Valdir", "Irineu", "Sérgio", "Élio", "Nelci", "Jandira"]
SOBRENOMES = ["Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves", "Pereira",
              "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho", "Araújo", "Melo",
              "Barbosa", "Rocha", "Dias", "Nascimento", "Andrade", "Moreira", "Nunes", "Marques",
              "Machado", "Mendes", "Freitas", "Cardoso", "Ramos", "Gonçalves", "Kowalski",
              "Schmidt", "Müller", "Bertolini", "Zanella", "Tomazini", "Fagundes", "Wolff",
              "Brandão", "Peixoto", "Dal Molin", "Bortolotto", "Hoffmann", "Conceição"]
PJ_PREF = ["AGROPECUÁRIA", "FAZENDAS REUNIDAS", "AGRÍCOLA", "SEMENTES", "GRÃOS", "CEREAIS"]
PJ_NUCLEO = ["VALE DO VERDE", "BOA ESPERANÇA", "SANTA RITA", "TRÊS IRMÃOS", "CERRADO NOVO",
             "SÃO JORGE", "PLANALTO", "RIO CLARO", "NOVA ALIANÇA", "DOIS CÓRREGOS",
             "SERRA AZUL", "BELA VISTA", "CHAPADÃO", "ÁGUA LIMPA", "SÃO MIGUEL", "PORTEIRA VELHA"]
PJ_SUF = ["LTDA", "LTDA", "LTDA", "S.A."]

ACENTOS = "ÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ"
SEM_ACENTO = "AAAAAEEEEIIIIOOOOOUUUUC"
TRANS = str.maketrans(ACENTOS, SEM_ACENTO)


# ---------------------------------------------------------------- utilitários
def dv(s, pesos):
    t = sum((ord(c) - 48) * p for c, p in zip(s, pesos))
    r = t % 11
    return "0" if r < 2 else str(11 - r)


def cpf_de(base9):
    d1 = dv(base9, range(10, 1, -1))
    return base9 + d1 + dv(base9 + d1, range(11, 1, -1))


P_CNPJ1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
P_CNPJ2 = [6] + P_CNPJ1


def cnpj_de(base12):
    d1 = dv(base12, P_CNPJ1)
    return base12 + d1 + dv(base12 + d1, P_CNPJ2)


def mascara_cpf(c):
    return f"{c[:3]}.{c[3:6]}.{c[6:9]}-{c[9:]}"


def mascara_cnpj(c):
    return f"{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}"


def mascara_cnae(c):
    return f"{c[:4]}-{c[4]}/{c[5:]}"


def q2(x):
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def fmt_br(d):
    s = f"{d:,.2f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def sem_acento_py(s):
    return re.sub(r"\s+", " ", s.strip(" ").upper().translate(TRANS))


usados = set()


def novo_cpf():
    while True:
        primeiro = "0" if R.random() < 0.15 else str(R.randint(1, 9))
        base = primeiro + "".join(str(R.randint(0, 9)) for _ in range(8))
        if len(set(base)) == 1:
            continue
        c = cpf_de(base)
        if c not in usados:
            usados.add(c)
            return c


def novo_cnpj(alfa=False, comeca_zero=False):
    alfabeto = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ" if alfa else "0123456789"
    while True:
        raiz = "".join(R.choice(alfabeto) for _ in range(8))
        if alfa and sum(ch.isalpha() for ch in raiz) < 2:
            continue
        if comeca_zero:
            raiz = "0" + raiz[1:]
        c = cnpj_de(raiz + "0001")
        if c not in usados:
            usados.add(c)
            return c


def sorteia_mun():
    return R.choices(MUNICIPIOS, weights=[m[3] for m in MUNICIPIOS])[0]


def novo_car(uf, mun):
    return f"{uf}-{mun}-{R.getrandbits(128):032X}"


def data_aleatoria(ini, fim):
    return ini + timedelta(days=R.randint(0, (fim - ini).days))


# ---------------------------------------------------------------- universo
def gera_universo():
    produtores, imoveis = [], []

    def novo_pf(mun=None, sobrenome=None):
        m = mun or sorteia_mun()
        nome = R.choice(PRIMEIROS) + " " + (sobrenome or R.choice(SOBRENOMES))
        if sobrenome is None and R.random() < 0.35:
            nome += " " + R.choice(SOBRENOMES)
        p = {"doc": novo_cpf(), "tipo": "PF", "nome": nome, "mun": m[0], "uf": m[2],
             "nome_mun": m[1], "cnae": None, "alfa": False, "conjuge": False}
        produtores.append(p)
        return p

    def novo_pj(alfa=False):
        m = sorteia_mun()
        nome = f"{R.choice(PJ_PREF)} {R.choice(PJ_NUCLEO)} {R.choice(PJ_SUF)}"
        p = {"doc": novo_cnpj(alfa=alfa), "tipo": "PJ", "nome": nome, "mun": m[0], "uf": m[2],
             "nome_mun": m[1], "cnae": R.choice(["0141501", "0115600"]) if alfa else R.choice(CNAES_PJ),
             "alfa": alfa, "conjuge": False}
        produtores.append(p)
        return p

    def novo_imovel(dono):
        if R.random() < 0.8:
            mun = (dono["mun"], dono["uf"])
        else:
            mesma_uf = [m for m in MUNICIPIOS if m[2] == dono["uf"]]
            m = R.choice(mesma_uf)
            mun = (m[0], m[2])
        cultura = R.choices(["SOJA", "MILHO", "ALGODAO"], weights=[60, 25, 15])[0]
        area = q2(min(8000, max(20, R.lognormvariate(5.6, 0.9))))
        plantio = data_aleatoria(date(2026, 9, 5), date(2026, 10, 25)) if R.random() < 0.88 else None
        im = {"car": novo_car(mun[1], mun[0]), "mun": mun[0], "uf": mun[1], "area": area,
              "cultura": cultura, "solo": R.choices([1, 2, 3], weights=[20, 50, 30])[0],
              "plantio": plantio, "donos": [dono["doc"]]}
        imoveis.append(im)
        return im

    for _ in range(170):
        p = novo_pf()
        for _ in range(R.choice([0, 1, 1, 1, 2, 2, 3])):
            novo_imovel(p)
    for _ in range(45):
        p = novo_pj()
        for _ in range(R.choice([1, 1, 2, 2, 3])):
            novo_imovel(p)
    for _ in range(5):
        p = novo_pj(alfa=True)
        if R.random() < 0.6:
            novo_imovel(p)

    # cônjuges: coproprietários de um imóvel de um PF
    candidatos = [p for p in produtores if p["tipo"] == "PF"
                  and any(p["doc"] in i["donos"] for i in imoveis)]
    for titular in R.sample(candidatos, 14):
        mun = next(m for m in MUNICIPIOS if m[0] == titular["mun"] and m[2] == titular["uf"])
        conj = novo_pf(mun=mun, sobrenome=titular["nome"].split()[-1])
        conj["conjuge"] = True
        im = next(i for i in imoveis if titular["doc"] in i["donos"])
        im["donos"].append(conj["doc"])
    return produtores, imoveis


# ---------------------------------------------------------------- ZARC
def gera_zarc():
    linhas = []
    padroes = {3: [30, 20, 20, 20, 20, 30], 2: [40, 20, 20, 20, 30], 1: [40, 30, 30, 40]}
    for cod, nome, uf, _ in MUNICIPIOS:
        base = (28 if uf in ("PR", "SC") else 27) + R.choice([0, 0, 1])
        for cultura, (rotulo, _) in CULTURAS.items():
            inicio = base + {"SOJA": 0, "MILHO": -1, "ALGODAO": 1}[cultura]
            for solo in (1, 2, 3):
                valores = padroes[solo][:-1] if cultura == "ALGODAO" else padroes[solo]
                decs = [""] * 36
                for k, v in enumerate(valores):
                    if 1 <= inicio + k <= 36:
                        decs[inicio + k - 1] = str(v)
                linhas.append([cod, rotulo, str(solo)] + decs)
    return linhas


# ---------------------------------------------------------------- escrita
def escreve(caminho, texto, encoding="utf-8"):
    os.makedirs(os.path.dirname(caminho), exist_ok=True)
    with open(caminho, "w", encoding=encoding, newline="") as f:
        f.write(texto)


def gera_fontes(out, produtores, imoveis):
    por_doc = {p["doc"]: p for p in produtores}
    mon_cars = set()
    for im in imoveis:
        if R.random() < 0.72:
            mon_cars.add(im["car"])

    # ---------- área declarada pela cooperativa (uma por imóvel)
    declarada = {im["car"]: q2(im["area"] * Decimal(str(R.uniform(0.99, 1.015)))) for im in imoveis}
    inflados = R.sample([im for im in imoveis if im["car"] in mon_cars], 6)
    for im in inflados:
        declarada[im["car"]] = q2(im["area"] * Decimal("1.15"))

    # ---------- cooperativa (CSV, Latin-1, uma linha por imóvel)
    membros = []
    for p in produtores:
        tem_imovel = any(p["doc"] in im["donos"] for im in imoveis)
        if p["alfa"] or not tem_imovel:
            continue
        if R.random() < (0.25 if p["conjuge"] else 0.65):
            membros.append(p)
    typo = set(R.sample([m["doc"] for m in membros], 5))
    linhas = []
    for p in membros:
        if p["tipo"] == "PF":
            r = R.random()
            if r < 0.75:
                doc = mascara_cpf(p["doc"])
            elif r < 0.90 or not p["doc"].startswith("0"):
                doc = p["doc"]
            else:
                doc = p["doc"].lstrip("0")
        else:
            doc = mascara_cnpj(p["doc"]) if R.random() < 0.85 else p["doc"]
        nome = p["nome"] if p["tipo"] == "PF" else p["nome"].title().replace("Ltda", "Ltda").replace("S.A.", "S.A.")
        variante = R.choice(["igual", "minusc", "duplo", "fim", "igual"])
        if variante == "minusc":
            nome = nome.lower()
        elif variante == "duplo":
            nome = nome.replace(" ", "  ", 1)
        elif variante == "fim":
            nome = nome + "  "
        mun_nome = p["nome_mun"]
        if p["doc"] in typo:
            i = R.randint(1, len(mun_nome) - 2)
            mun_nome = mun_nome[:i] + mun_nome[i + 1:]
        else:
            v = R.choice(["igual", "sem_acento", "maiusc", "minusc", "espaco"])
            if v == "sem_acento":
                mun_nome = mun_nome.upper().translate(TRANS).title()
            elif v == "maiusc":
                mun_nome = mun_nome.upper()
            elif v == "minusc":
                mun_nome = mun_nome.lower()
            elif v == "espaco":
                mun_nome = "  " + mun_nome
        cnae = ""
        if p["tipo"] == "PJ" and R.random() >= 0.15:
            cnae = mascara_cnae(p["cnae"])
        for im in imoveis:
            if p["doc"] in im["donos"]:
                linhas.append([doc, nome, "F" if p["tipo"] == "PF" else "J", cnae, mun_nome, p["uf"],
                               im["car"], fmt_br(declarada[im["car"]]), CULTURAS[im["cultura"]][0]])
    idx = list(range(len(linhas)))
    R.shuffle(idx)
    for i in idx[:4]:
        linhas[i][6] = linhas[i][6].lower()
    for i in idx[4:7]:
        linhas[i][6] = "  " + linhas[i][6] + " "
    for i in idx[7:9]:
        linhas[i][6] = linhas[i][6][:15]
    for i in idx[9:12]:
        linhas[i][7] = ""
    linhas[idx[12]][7] = "n/d"
    cab = ["cpf_cnpj", "nome_cooperado", "tipo", "cnae", "municipio", "uf", "car", "area_ha", "cultura"]
    texto = "\r\n".join(";".join(l) for l in [cab] + linhas) + "\r\n"
    escreve(f"{out}/landing/cooperativa/cooperados_{TAG}.csv", texto, encoding="latin-1")

    # ---------- revenda (TXT largura fixa, duas lojas)
    def registro(p, doc):
        cult = "001"
        for im in imoveis:
            if p["doc"] in im["donos"]:
                cult = CULTURAS[im["cultura"]][1]
                break
        nome = sem_acento_py(p["nome"])[:30].ljust(30)
        dt = data_aleatoria(date(2015, 1, 1), date(2026, 9, 30)).strftime("%Y%m%d")
        return "D" + ("1" if p["tipo"] == "PF" else "2") + doc.rjust(14, "0") + nome + p["mun"] + cult + dt

    elegiveis = [p for p in produtores if not p["alfa"]]
    loja1 = [p for p in elegiveis if R.random() < (0.5 if p["tipo"] == "PF" else 0.4)]
    loja2 = [p for p in elegiveis if R.random() < 0.25]
    erros_dv = set(R.sample([p["doc"] for p in loja1 if p["tipo"] == "PF"], 4))
    for nome_arq, lista, extra in (("loja01", loja1, 0), ("loja02", loja2, 1)):
        regs = []
        for p in lista:
            doc = p["doc"]
            if nome_arq == "loja01" and doc in erros_dv:
                doc = doc[:-1] + str((int(doc[-1]) + 1) % 10)
            regs.append(registro(p, doc))
        R.shuffle(regs)
        texto = "\n".join([f"H{TAG}REVENDA-{nome_arq.upper()}"] + regs + [f"T{len(regs) + extra:06d}"]) + "\n"
        escreve(f"{out}/landing/revenda/clientes_{TAG}_{nome_arq}.txt", texto, encoding="ascii")

    # ---------- monitoramento (JSON multilinha)
    objs = []
    for im in imoveis:
        if im["car"] not in mon_cars:
            continue
        donos = im["donos"]
        objs.append({
            "car": im["car"],
            "geo": {"municipio": {"ibge": int(im["mun"]), "uf": im["uf"]},
                    "area_ha": float(im["area"]), "solo_tipo": im["solo"]},
            "proprietarios": [{"doc": d, "tipo": por_doc[d]["tipo"],
                               "participacao": round(1 / len(donos), 4)} for d in donos],
            "safra_atual": {"cultura": im["cultura"],
                            "plantio_detectado": im["plantio"].isoformat() if im["plantio"] else None,
                            "confianca": round(R.uniform(0.6, 0.99), 2)},
            "status_car": R.choice(["ATIVO", "ATIVO", "ATIVO", "PENDENTE"]),
        })
    R.shuffle(objs)
    escreve(f"{out}/landing/monitoramento/imoveis_{TAG}.json",
            "[\n" + ",\n".join(" " + json.dumps(o, ensure_ascii=False) for o in objs) + "\n]\n")

    # ---------- cadastro PJ (XML)
    def estab(p, sem_principal=False, um_cnae=False):
        cnaes = []
        if not sem_principal:
            cnaes.append(("principal", p["cnae"]))
        if not um_cnae:
            outros = [c for c in sorted(set(CNAES_PJ)) if c != p["cnae"]]
            for c in R.sample(outros, 1 if sem_principal else R.choice([0, 1, 1, 2])):
                cnaes.append(("secundario", c))
        abertura = (data_aleatoria(date(2026, 7, 27), date(2026, 10, 20)) if p["alfa"]
                    else data_aleatoria(date(1995, 1, 1), date(2020, 12, 31)))
        xs = [f'  <estabelecimento cnpj={quoteattr(p["doc"])} matriz="S" abertura="{abertura.isoformat()}">',
              f'    <razao_social>{escape(sem_acento_py(p["nome"]))}</razao_social>']
        xs += [f'    <cnae tipo="{t}" codigo="{c}"/>' for t, c in cnaes]
        xs += [f'    <municipio ibge="{p["mun"]}" uf="{p["uf"]}"/>', "  </estabelecimento>"]
        return "\n".join(xs)

    pjs = [p for p in produtores if p["tipo"] == "PJ" and (p["alfa"] or R.random() < 0.85)]
    sem_princ = set(R.sample([p["doc"] for p in pjs if not p["alfa"]], 3))
    R.shuffle(pjs)
    corpo = "\n".join(estab(p, sem_principal=p["doc"] in sem_princ) for p in pjs)
    escreve(f"{out}/landing/cadastro_pj/estabelecimentos_{TAG}.xml",
            '<?xml version="1.0" encoding="UTF-8"?>\n<estabelecimentos>\n' + corpo + "\n</estabelecimentos>\n")

    # arquivo de uma semana antes, só para o exercício sobre inferência de schema
    antigos = []
    for k in range(8):
        m = sorteia_mun()
        antigos.append({"doc": novo_cnpj(comeca_zero=k < 3), "tipo": "PJ",
                        "nome": f"{R.choice(PJ_PREF)} {R.choice(PJ_NUCLEO)} LTDA",
                        "mun": m[0], "uf": m[2], "cnae": R.choice(CNAES_PJ), "alfa": False})
    corpo = "\n".join(estab(p, um_cnae=True) for p in antigos)
    escreve(f"{out}/landing/cadastro_pj_semana_anterior/estabelecimentos_20261020.xml",
            '<?xml version="1.0" encoding="UTF-8"?>\n<estabelecimentos>\n' + corpo + "\n</estabelecimentos>\n")

    # ---------- assistência técnica (JSON Lines, desafio final)
    fatores = {"alqueire_paulista": Decimal("2.42"), "alqueire_goiano": Decimal("4.84"), "ha": Decimal("1")}
    visitas = []
    pfs = [p for p in produtores if p["tipo"] == "PF"]
    for k, p in enumerate(R.sample(pfs, 25)):
        ims = [im for im in imoveis if p["doc"] in im["donos"]]
        if ims:
            im = R.choice(ims)
            car, area_ha, cultura = im["car"], im["area"], im["cultura"]
        else:
            car = novo_car(p["uf"], p["mun"])
            area_ha, cultura = q2(R.uniform(30, 400)), R.choice(list(CULTURAS))
        unidade = ("alqueire_paulista" if p["uf"] in ("PR", "SC", "MS")
                   else "alqueire_goiano" if p["uf"] in ("GO", "MT") else "ha")
        if R.random() < 0.2:
            unidade = "ha"
        area = (area_ha / fatores[unidade]).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        cpf = mascara_cpf(p["doc"])
        if k < 2:
            cpf = cpf[:-1] + str((int(cpf[-1]) + 1) % 10)
        if k == 2:
            car = car[:15]
        visitas.append({"cpf": cpf, "nome": p["nome"],
                        "propriedade": {"car": car, "area": str(max(area, 1)), "unidade": unidade,
                                        "cultura": CULTURAS[cultura][0]},
                        "visita": data_aleatoria(date(2026, 10, 1), date(2026, 10, 26)).isoformat()})
    escreve(f"{out}/landing/assistencia_tecnica/visitas_{TAG}.jsonl",
            "\n".join(json.dumps(v, ensure_ascii=False) for v in visitas) + "\n")


def gera_referencias(out):
    linhas = ["codigo_ibge;nome;uf"] + [f"{c};{n};{u}" for c, n, u, _ in MUNICIPIOS]
    escreve(f"{out}/referencia/municipios_ibge.csv", "\n".join(linhas) + "\n")
    cab = ["geocodigo", "cultura", "solo"] + [f"dec{i}" for i in range(1, 37)]
    escreve(f"{out}/referencia/zarc_2026_27.csv",
            "\n".join(";".join(l) for l in [cab] + gera_zarc()) + "\n")
    contrato = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "produtor_rural.v1",
        "title": "Produtor rural para modelagem de crédito",
        "type": "object",
        "required": ["documento", "tipo_pessoa", "nome", "municipio_ibge", "uf",
                     "imoveis", "area_total_ha", "fontes", "data_referencia"],
        "additionalProperties": False,
        "properties": {
            "documento": {"type": "string", "pattern": "^([0-9]{11}|[0-9A-Z]{12}[0-9]{2})$"},
            "tipo_pessoa": {"type": "string", "enum": ["PF", "PJ"]},
            "nome": {"type": "string", "minLength": 3},
            "cnae_principal": {"type": ["string", "null"], "pattern": "^[0-9]{7}$"},
            "municipio_ibge": {"type": "string", "pattern": "^[0-9]{7}$"},
            "uf": {"type": "string", "pattern": "^[A-Z]{2}$"},
            "imoveis": {"type": "array", "items": {"$ref": "#/$defs/imovel"}},
            "area_total_ha": {"type": "number", "minimum": 0},
            "fontes": {"type": "array", "minItems": 1, "uniqueItems": True,
                       "items": {"enum": ["COOPERATIVA", "REVENDA", "MONITORAMENTO", "CADASTRO_PJ"]}},
            "data_referencia": {"type": "string", "format": "date"},
        },
        "allOf": [
            {"if": {"properties": {"tipo_pessoa": {"const": "PF"}}},
             "then": {"properties": {"documento": {"pattern": "^[0-9]{11}$"}}}},
            {"if": {"properties": {"tipo_pessoa": {"const": "PJ"}}},
             "then": {"required": ["cnae_principal"],
                      "properties": {"documento": {"pattern": "^[0-9A-Z]{12}[0-9]{2}$"},
                                     "cnae_principal": {"type": "string"}}}},
        ],
        "$defs": {"imovel": {
            "type": "object",
            "required": ["codigo_car", "area_ha", "zarc_situacao"],
            "additionalProperties": False,
            "properties": {
                "codigo_car": {"type": "string", "pattern": "^[A-Z]{2}-[0-9]{7}-[0-9A-F]{32}$"},
                "area_ha": {"type": "number", "exclusiveMinimum": 0},
                "cultura": {"type": ["string", "null"], "pattern": "^[A-Z_]+$"},
                "risco_zarc": {"enum": [20, 30, 40, None]},
                "zarc_situacao": {"enum": ["INDICADO", "NAO_INDICADO", "SEM_DADO"]},
            }}},
    }
    escreve(f"{out}/contratos/produtor_rural.v1.schema.json",
            json.dumps(contrato, ensure_ascii=False, indent=2) + "\n")


# ---------------------------------------------------------------- gabarito
# Reimplementação em Python puro das mesmas regras do notebook, lendo os
# arquivos gerados. Serve para conferir os resultados obtidos no Spark.
def sem_acento(s):
    return None if s is None else sem_acento_py(s)


def sem_mascara(s):
    return re.sub(r"[^0-9A-Z]", "", s.upper())


def lpad(s, n, ch="0"):
    return s[:n] if len(s) >= n else s.rjust(n, ch)


def documento_norm(doc, tipo):
    if doc is None:
        return None
    d = sem_mascara(doc)
    if tipo == "PF":
        return lpad(re.sub(r"^0+(?=[0-9]{11}$)", "", d), 11)
    if tipo == "PJ":
        return lpad(d, 14)
    return None


def area_br(s):
    if s is None:
        return None
    try:
        return q2(s.replace(".", "").replace(",", "."))
    except Exception:
        return None


def documento_valido(d, t):
    if d is None:
        return False
    if t == "PF":
        return (re.fullmatch(r"[0-9]{11}", d) is not None and len(set(d)) > 1
                and cpf_de(d[:9]) == d)
    if t == "PJ":
        return re.fullmatch(r"[0-9A-Z]{12}[0-9]{2}", d) is not None and cnpj_de(d[:12]) == d
    return False


def decendio(dt):
    return (dt.month - 1) * 3 + min(math.ceil(dt.day / 10), 3)


def gabarito(out):
    G = {}
    mun_ref = {}
    with open(f"{out}/referencia/municipios_ibge.csv", encoding="utf-8") as f:
        for r in csv.DictReader(f, delimiter=";"):
            mun_ref[(sem_acento(r["nome"]), r["uf"])] = r["codigo_ibge"]

    # cooperativa
    with open(f"{out}/landing/cooperativa/cooperados_{TAG}.csv", encoding="latin-1", newline="") as f:
        coop = [{k: (v if v != "" else None) for k, v in r.items()} for r in csv.DictReader(f, delimiter=";")]
    grupos, sem_ibge = {}, {}
    for r in coop:
        tp = {"F": "PF", "J": "PJ"}.get(r["tipo"])
        doc = documento_norm(r["cpf_cnpj"], tp)
        mun = mun_ref.get((sem_acento(r["municipio"]), r["uf"]))
        if mun is None:
            k = (r["municipio"], r["uf"])
            sem_ibge[k] = sem_ibge.get(k, 0) + 1
        cnae = re.sub(r"[^0-9]", "", r["cnae"]) if r["cnae"] else None
        cnae = cnae or None
        im = (r["car"].strip(" ").upper(), area_br(r["area_ha"]), sem_acento(r["cultura"]), None, "SEM_DADO")
        chave = (doc, tp, sem_acento(r["nome_cooperado"]), cnae, mun, r["uf"])
        grupos.setdefault(chave, []).append(im)
    coop_conf = [dict(zip(["documento", "tipo_pessoa", "nome", "cnae_principal", "municipio_ibge", "uf"], k),
                      imoveis=v) for k, v in grupos.items()]
    G["cooperativa"] = {"linhas": len(coop), "produtores": len(coop_conf),
                        "linhas_sem_codigo_ibge": sum(sem_ibge.values()),
                        "municipios_sem_codigo_ibge": sorted(f"{m.strip()} / {u}" for m, u in sem_ibge)}

    # revenda
    rev_conf, rev_info = [], {}
    for arq in sorted(os.listdir(f"{out}/landing/revenda")):
        linhas = open(f"{out}/landing/revenda/{arq}", encoding="ascii").read().splitlines()
        det = [l for l in linhas if l[:1] == "D"]
        trailer = int(next(l for l in linhas if l[:1] == "T")[1:7])
        rev_info[arq] = {"detalhes": len(det), "trailer": trailer}
        for l in det:
            tp = {"1": "PF", "2": "PJ"}.get(l[1:2].strip(" "))
            mun = l[46:53].strip(" ")
            rev_conf.append({"documento": documento_norm(l[2:16].strip(" "), tp), "tipo_pessoa": tp,
                             "nome": sem_acento(l[16:46].strip(" ")), "cnae_principal": None,
                             "municipio_ibge": mun, "uf": UF_IBGE.get(mun[:2]), "imoveis": []})
    G["revenda"] = {"registros_D": len(rev_conf), "por_arquivo": rev_info,
                    "arquivos_com_trailer_divergente": [a for a, v in rev_info.items()
                                                        if v["detalhes"] != v["trailer"]]}

    # ZARC
    zarc = {}
    with open(f"{out}/referencia/zarc_2026_27.csv", encoding="utf-8") as f:
        for r in csv.DictReader(f, delimiter=";"):
            for i in range(1, 37):
                v = r[f"dec{i}"]
                if v:
                    zarc[(r["geocodigo"], sem_acento(r["cultura"]), int(r["solo"]), i)] = int(v)
    G["zarc"] = {"linhas_tabela_larga": sum(1 for _ in open(f"{out}/referencia/zarc_2026_27.csv")) - 1,
                 "linhas_tabela_longa": len(zarc)}

    # monitoramento
    objs = json.load(open(f"{out}/landing/monitoramento/imoveis_{TAG}.json", encoding="utf-8"))
    linhas_mon, sit_por_car = [], {}
    for o in objs:
        mun = str(o["geo"]["municipio"]["ibge"]).rjust(7, "0")
        pl = o["safra_atual"]["plantio_detectado"]
        pl = date.fromisoformat(pl) if pl else None
        cult = sem_acento(o["safra_atual"]["cultura"])
        solo = o["geo"]["solo_tipo"]
        risco = zarc.get((mun, cult, solo, decendio(pl))) if pl else None
        sit = "SEM_DADO" if pl is None else ("INDICADO" if risco is not None else "NAO_INDICADO")
        sit_por_car[o["car"]] = sit
        for p in o["proprietarios"]:
            linhas_mon.append({"documento": documento_norm(p["doc"], p["tipo"]), "tipo_pessoa": p["tipo"],
                               "municipio_ibge": mun, "uf": o["geo"]["municipio"]["uf"],
                               "im": (o["car"], q2(o["geo"]["area_ha"]), cult, risco, sit)})
    grupos = {}
    for l in linhas_mon:
        grupos.setdefault((l["documento"], l["tipo_pessoa"]), []).append(l)
    mon_conf = []
    for (doc, tp), ls in grupos.items():
        maior = max(ls, key=lambda x: x["im"][1])
        mon_conf.append({"documento": doc, "tipo_pessoa": tp, "nome": None, "cnae_principal": None,
                         "municipio_ibge": maior["municipio_ibge"], "uf": maior["uf"],
                         "imoveis": [x["im"] for x in ls]})
    contagem = {}
    for s in sit_por_car.values():
        contagem[s] = contagem.get(s, 0) + 1
    G["monitoramento"] = {"imoveis": len(objs), "linhas_apos_explode": len(linhas_mon),
                          "produtores": len(mon_conf), "imoveis_por_zarc_situacao": dict(sorted(contagem.items()))}

    # cadastro PJ
    import xml.etree.ElementTree as ET
    raiz = ET.parse(f"{out}/landing/cadastro_pj/estabelecimentos_{TAG}.xml").getroot()
    pj_conf = []
    for e in raiz.findall("estabelecimento"):
        princ = [c.get("codigo") for c in e.findall("cnae") if c.get("tipo") == "principal"]
        m = e.find("municipio")
        pj_conf.append({"documento": documento_norm(e.get("cnpj"), "PJ"), "tipo_pessoa": "PJ",
                        "nome": sem_acento(e.findtext("razao_social")),
                        "cnae_principal": princ[0] if princ else None,
                        "municipio_ibge": m.get("ibge"), "uf": m.get("uf"), "imoveis": []})
    G["cadastro_pj"] = {"estabelecimentos": len(pj_conf),
                        "sem_cnae_principal": sum(1 for p in pj_conf if p["cnae_principal"] is None),
                        "cnpj_alfanumerico": sum(1 for p in pj_conf if not p["documento"].isdigit())}

    # união
    PRIO = {"CADASTRO_PJ": 1, "COOPERATIVA": 2, "MONITORAMENTO": 3, "REVENDA": 4}
    base = []
    for fonte, lista in (("COOPERATIVA", coop_conf), ("REVENDA", rev_conf),
                         ("MONITORAMENTO", mon_conf), ("CADASTRO_PJ", pj_conf)):
        for r in lista:
            base.append(dict(r, fonte=fonte, prioridade=PRIO[fonte]))
    G["uniao"] = {"linhas": len(base), "documentos_distintos": len({r["documento"] for r in base})}

    # divergência de área (exercício)
    coop_area = {(r["documento"], i[0]): i[1] for r in coop_conf for i in r["imoveis"]}
    mon_area = {(r["documento"], i[0]): i[1] for r in mon_conf for i in r["imoveis"]}
    G["exercicio_divergencia_area_acima_de_2pct"] = sum(
        1 for k, a in coop_area.items()
        if a is not None and k in mon_area and abs(a - mon_area[k]) / mon_area[k] > Decimal("0.02"))

    # consolidação
    por_doc = {}
    for r in base:
        por_doc.setdefault(r["documento"], []).append(r)
    consolidado = []
    for doc, rs in por_doc.items():
        rs = sorted(rs, key=lambda x: x["prioridade"])
        reg = {"documento": doc}
        for c in ["tipo_pessoa", "nome", "cnae_principal", "municipio_ibge", "uf"]:
            reg[c] = next((x[c] for x in rs if x[c] is not None), None)
        escolhido = {}
        for x in rs:
            pi = 1 if x["fonte"] == "MONITORAMENTO" else 2
            for im in x["imoveis"]:
                if im[0] not in escolhido or pi < escolhido[im[0]][0]:
                    escolhido[im[0]] = (pi, im)
        ims = [v[1] for v in escolhido.values()]
        reg["imoveis"] = ims
        areas = [i[1] for i in ims]
        reg["area_total_ha"] = None if any(a is None for a in areas) else sum(areas, Decimal("0.00"))
        reg["fontes"] = sorted({x["fonte"] for x in rs})
        consolidado.append(reg)

    # validação
    padrao_car = re.compile(r"[A-Z]{2}-[0-9]{7}-[0-9A-F]{32}")
    regras = {
        "documento_invalido": lambda r: not documento_valido(r["documento"], r["tipo_pessoa"]),
        "nome_ausente": lambda r: r["nome"] is None,
        "cnae_ausente_pj": lambda r: r["tipo_pessoa"] == "PJ" and r["cnae_principal"] is None,
        "cnae_formato": lambda r: r["cnae_principal"] is not None
                                  and re.fullmatch(r"[0-9]{7}", r["cnae_principal"]) is None,
        "municipio_ausente": lambda r: r["municipio_ibge"] is None,
        "area_invalida": lambda r: any(i[1] is None or i[1] <= 0 for i in r["imoveis"]),
        "car_formato": lambda r: any(padrao_car.fullmatch(i[0]) is None for i in r["imoveis"]),
    }
    validos, rechaco, por_regra = [], [], {k: 0 for k in regras}
    for r in consolidado:
        erros = [k for k, f in regras.items() if f(r)]
        for k in erros:
            por_regra[k] += 1
        (rechaco if erros else validos).append(r)
    por_uf, sit = {}, {}
    for r in validos:
        por_uf[r["uf"]] = por_uf.get(r["uf"], 0) + 1
        for i in r["imoveis"]:
            sit[i[4]] = sit.get(i[4], 0) + 1
    G["consolidacao"] = {"produtores": len(consolidado)}
    G["validacao"] = {"validos": len(validos), "rechacados": len(rechaco),
                      "violacoes_por_regra": por_regra,
                      "validos_por_uf": dict(sorted(por_uf.items())),
                      "imoveis_validos_por_zarc_situacao": dict(sorted(sit.items())),
                      "soma_area_total_validos_ha": str(sum((r["area_total_ha"] for r in validos), Decimal("0.00")))}
    return G


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "dados"
    produtores, imoveis = gera_universo()
    gera_referencias(out)
    gera_fontes(out, produtores, imoveis)
    G = gabarito(out)
    destino = os.path.join(os.path.dirname(os.path.abspath(out)), "gabarito_esperado.json")
    with open(destino, "w", encoding="utf-8") as f:
        json.dump(G, f, ensure_ascii=False, indent=2)
    print(f"Arquivos gerados em {out}/ e gabarito em {destino}")
    print(json.dumps(G["validacao"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
